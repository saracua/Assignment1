package com.example.splashscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EmployeeLogin extends AppCompatActivity {

    private Button eLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_login);

        EditText username = findViewById(R.id.etUser);
        EditText password = findViewById(R.id.etPassword);
        eLogin = findViewById(R.id.btnLogIn);

        eLogin.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if (username.getText().toString().equals("Admin") && password.getText().toString()
                        .equals("Admin")) {
                    Toast.makeText(getApplicationContext(), "LOGIN SUCCESSFUL",
                            Toast.LENGTH_SHORT).show();
                } else
                    Toast.makeText(getApplicationContext(), "LOGIN FAILED",
                            Toast.LENGTH_SHORT).show();

                Intent LogIn = new Intent(EmployeeLogin.this, SQLite.class);
                startActivity(LogIn);
            }
        });
    }
}