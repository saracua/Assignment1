package com.example.splashscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class EventHandling extends AppCompatActivity implements View.OnClickListener {
    private Button home;
    LinearLayout layout;
    Button btnOk;
    Button btnCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_handling);
        layout = (LinearLayout) findViewById(R.id.Layout);
        btnOk = new Button(this); // Creating the Button
        btnCancel = new Button(this);
        btnOk.setText("OK"); // Setting the Label
        btnOk.setOnClickListener(this);
        btnCancel.setText("Cancel"); // Cancel the Instance
        btnCancel.setOnClickListener(this);
        layout.addView(btnOk); // Adding button to the Layout
        layout.addView(btnCancel);
        home = findViewById(R.id.btnHome);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView myText = (TextView) findViewById(R.id.myText);
                myText.setText("Long Click To Go Home");

                home.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View view) {
                        TextView myText = (TextView) findViewById(R.id.myText);
                        myText.setText("Going Home Now....");
                        return false;
                    }
                });
            }
        });
    }

    @Override
    public void onClick(View view) {
        Button btn = (Button) view;
        if (btn == btnOk)
            Toast.makeText(this, "Item Purchased", Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(this, "Order Cancelled", Toast.LENGTH_SHORT).show();
    }

    public void btnRate(View view) {
        {
            Intent intentRate = new Intent(this, RatingBar.class);
            this.startActivity(intentRate);
        }
    }
}