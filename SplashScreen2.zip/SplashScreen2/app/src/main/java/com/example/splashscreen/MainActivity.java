package com.example.splashscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void btnCall_Click(View V) {
        Intent intentCallButton = new Intent(this, CallButton.class);
        this.startActivity(intentCallButton);
    }

    public void btnSMS_Click(View view) {
        {
            Intent intentMsg = new Intent(this, SendSMS.class);
            this.startActivity(intentMsg);
        }
    }

    public void btnPurchase(View view) {
        {
            Intent intentPurchase = new Intent(this, MenuItems.class);
            this.startActivity(intentPurchase);
        }
    }

    public void btnWebVer(View view) {
        {
            Intent intentWebVer = new Intent(this, WebBrowse.class);
            this.startActivity(intentWebVer);
        }
    }

    public void btnAbout(View V) {
        Intent intentAboutUs = new Intent(this, AboutUs.class);
        this.startActivity(intentAboutUs);
    }

    public void btnEmpLogIn(View V) {
        Intent intentEmpLogIn = new Intent(this, EmployeeLogin.class);
        this.startActivity(intentEmpLogIn);
    }

    public void btnMap(View V) {
        Intent intentMap = new Intent(this, GoogleMap.class);
        this.startActivity(intentMap);
    }
}