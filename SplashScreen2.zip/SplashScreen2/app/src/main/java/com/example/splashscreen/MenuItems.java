package com.example.splashscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MenuItems extends AppCompatActivity {
    Button button;
    RadioButton VerButton;
    RadioGroup radioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_items);
        radioGroup=(RadioGroup)findViewById(R.id.radioGroup);
    }

    public void btnCart(View V) {
        Intent intentCartButton = new Intent(this, EventHandling.class);
        this.startActivity(intentCartButton);

    }

    public void onclickbuttonMethod(View v) {
        int selectedId = radioGroup.getCheckedRadioButtonId();
        VerButton = (RadioButton) findViewById(selectedId);
        if (selectedId == -1) {
            Toast.makeText(this, "Nothing selected", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Added to Cart", Toast.LENGTH_SHORT).show();
        }
    }

        }
