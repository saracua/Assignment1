package com.example.splashscreen;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class MusicShopDB extends SQLiteOpenHelper {

    final static String DATABASE_NAME = "dbProducts"; // DB Name
    final static int DATABASE_VERSION = 1;
    final static String TABLE_NAME = "tbAlbums"; // Table name
    final static String COLUMN1_ALBUM_NAME = "albumName"; // Column num & name
    final static String COLUMN2_ARTIST_NAME = "artistName"; // Column num & name

    public MusicShopDB(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + "(" + COLUMN1_ALBUM_NAME
                + "TEXT," + COLUMN2_ARTIST_NAME + "TEXT)";
        // SQL Query Create Table tbAlbums
        sqLiteDatabase.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE " + TABLE_NAME);
        onCreate(sqLiteDatabase);
    }

    public void saveAlbum(String alName, String arName) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(COLUMN1_ALBUM_NAME, alName);
        cv.put(COLUMN2_ARTIST_NAME, arName);
        sqLiteDatabase.insert(TABLE_NAME, null, cv);
    }

    public ArrayList<String> saveAlbum(){
        ArrayList<String> albumNames = new ArrayList<String>();
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT " + COLUMN1_ALBUM_NAME
                + "FROM " + TABLE_NAME, null);
        cursor.moveToFirst();
        do {
            albumNames.add(cursor.getString(0));
        } while (cursor.moveToNext());
        return albumNames;
    }
}