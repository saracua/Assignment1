package com.example.splashscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class SQLite extends AppCompatActivity {
    EditText album_name, artist_name;
    Button btnSave;
    LinearLayout layout;
    MusicShopDB mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sqlite);
        mydb = new MusicShopDB(this);
        album_name = findViewById(R.id.etAlbumName);
        artist_name = findViewById(R.id.etArtistName);
        btnSave = findViewById(R.id.btnSave);
        layout = findViewById(R.id.myView);
        //saveAlbum();
        btnSave.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                mydb.saveAlbum(album_name.getText().toString(), artist_name.getText().toString());
                TextView tv = new TextView(SQLite.this);
                tv.setText(album_name.getText().toString());
                layout.addView(tv);
                Toast.makeText(SQLite.this, "Album Info Saved",
                        Toast.LENGTH_SHORT).show();
                album_name.setText("");
                artist_name.setText("");
            }
        });
    }
    private void saveAlbum(){
        ArrayList<String> albumNames = mydb.saveAlbum();
        for (String name : albumNames){
            TextView tv = new TextView(this);
            tv.setText(name);
            layout.addView(tv);
        }
    }
}