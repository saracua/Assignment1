package com.example.splashscreen;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SendSMS extends AppCompatActivity {
    private EditText phone, message;
    private Button send;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_sms);

        phone = findViewById(R.id.etPhone);
        message = findViewById(R.id.etMessage);
        send = findViewById(R.id.btnSend);

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                        String phoneNo = phone.getText().toString();
                        String msg = message.getText().toString();
                        try {
                            SmsManager smsmanager = SmsManager.getDefault();
                            smsmanager.sendTextMessage(phoneNo, null, msg, null, null);
                            Toast.makeText(SendSMS.this, "Message Sent", Toast.LENGTH_SHORT).show();
                        } catch (Exception exception) {
                            exception.printStackTrace();
                            Toast.makeText(SendSMS.this, "Message Failed", Toast.LENGTH_SHORT).show();
                        }

                    } else {
                        requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 1);
                    }
                }
            }
        });
    };
}