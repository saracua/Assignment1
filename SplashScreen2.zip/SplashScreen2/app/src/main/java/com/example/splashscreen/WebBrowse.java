package com.example.splashscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;

public class WebBrowse extends AppCompatActivity {
    WebView browser;
    EditText webAddress;
    Button btn_Go;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_browse);
        browser = (WebView) findViewById(R.id.Website);
        webAddress = (EditText) findViewById(R.id.SiteURL);
        btn_Go = (Button) findViewById(R.id.btnGo);

        browser.setWebViewClient(new aisWebViewClient());
        btn_Go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = webAddress.getText().toString();
                browser.getSettings().setLoadsImagesAutomatically(true);
                browser.getSettings().setJavaScriptEnabled(true);
                browser.loadUrl(url);
            }
        });
    }

    private class aisWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }
}