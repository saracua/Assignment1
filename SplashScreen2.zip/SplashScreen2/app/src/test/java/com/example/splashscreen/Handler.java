package com.example.splashscreen;

public class Handler {
}
